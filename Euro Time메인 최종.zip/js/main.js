
//nav_btn

var nav = document.querySelector(".nav");
var navWrap = document.querySelector(".nav .wrap");
var navWrapInner = document.querySelector(".nav .wrap .inner");
var navBtn = document.querySelector(".nav_btn");

navBtn.addEventListener('click', function (){
    nav.classList.toggle('on')
});

navWrap.addEventListener('click', function(e) {
    if (!navWrapInner.contains(e.target)) {
        nav.classList.remove('on');
    }
});